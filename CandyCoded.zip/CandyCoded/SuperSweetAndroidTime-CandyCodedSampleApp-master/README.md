# SuperSweetAndroidTime-CandyCodedSampleApp
The sample app for the Super Sweet Android Time course, a candy store app called Candy Coded.  Continues from where the Try Android course's sample app left off - https://github.com/codeschool/TryAndroid-CandyCodedSampleApp.
